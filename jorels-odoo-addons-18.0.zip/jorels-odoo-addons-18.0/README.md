![Jorels](https://www.jorels.com/web/image/res.company/1/logo)
### Jorels SAS - Copyright (2024)

# Jorels Odoo Addons

Jorels Odoo Addons

## Name
Jorels Odoo Addons

## Description
Modulos de Odoo de código y licencia abierta.

## Installation
Instalar normalmente como cualquier otro modulo de Odoo.

## Usage
Usar como cualquier otro módulo de Odoo, teniendo en cuenta la reglamentación legal que corresponda en las configuraciones de Odoo.

## Support
Email: info@jorels.com

Telegram: @Jorels_SAS

## Contributing
Colaboradores varios citados en cada proyecto.

## Authors and acknowledgment
Jorels SAS

## License
LGPL v3 y AGPL v3, dependiendo el módulo.

## Project status
En producción y funcionan perfectamente.
