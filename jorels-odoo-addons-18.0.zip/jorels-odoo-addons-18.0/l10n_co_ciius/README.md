![Jorels](https://www.jorels.com/web/image/res.company/1/logo)
### Jorels SAS - Copyright (2024)

# Ciiu's for Colombia

## Module name
l10n_co_ciius

## Support

[info@jorels.com](mailto:info@jorels.com)

[Telegram: @Jorels_SAS](https://t.me/Jorels_SAS)

[https://www.jorels.com](https://www.jorels.com)

## Authors and acknowledgment
Jorels SAS

## License
Under LGPL (Lesser General Public License)

## Project status
Tested in production on Odoo.

## Description
Ciiu's for Colombia
