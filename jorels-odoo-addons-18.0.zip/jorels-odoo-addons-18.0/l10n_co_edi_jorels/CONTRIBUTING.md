l10n_co_edi_jorels
------------------

Copyright (2024) - Jorels SAS

[info@jorels.com](mailto:info@jorels.com)

[https://www.jorels.com](https://www.jorels.com)

Under LGPL (Lesser General Public License)

Contributing
============

Jorge Sanabria (2019, 2024) - [js@jorels.com](mailto:js@jorels.com)

July Caballero (2022, 2023) - [jc@jorels.com](mailto:jc@jorels.com)

Leonardo Martinez (2019, 2020) - [lotharius96@protonmail.ch](mailto:lotharius96@protonmail.ch)
