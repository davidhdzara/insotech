![Jorels](https://www.jorels.com/web/image/res.company/1/logo)
### Jorels SAS - Copyright (2024)

# Electronic invoicing for Colombia

## Module name
l10n_co_edi_jorels

## Support

[info@jorels.com](mailto:info@jorels.com)

[Telegram: @Jorels_SAS](https://t.me/Jorels_SAS)

[https://www.jorels.com](https://www.jorels.com)

## Authors and acknowledgment
Jorels SAS

## License
Under LGPL (Lesser General Public License)

## Project status
Tested in production on Odoo.

## Description
Odoo module for electronic invoicing for Colombia
